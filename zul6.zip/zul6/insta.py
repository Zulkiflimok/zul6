{
    "creator": "Imjustgood",
    "result": {
        "biography": "Designer & content creator. Mechanical keyboards, computers, tech, coffee & music.",
        "business": {
            "category": "Artist",
            "status": false
        },
        "follower": "4957",
        "following": "204",
        "fullname": "Andi",
        "highlights": [
            {
                "count": "4",
                "cover": "https://scontent-hel3-1.cdninstagram.com/v/t51.2885-15/e35/c0.420.1080.1080a/s150x150/174239432_287086226230900_2559666432876705603_n.jpg?_nc_ht=scontent-hel3-1.cdninstagram.com&_nc_cat=104&_nc_ohc=BPLHKVB7T3EAX9rDmP1&edm=ALbqBD0BAAAA&ccb=7-4&oh=00_AT98aTtCkHXqnDqKqX5CgCeOMFZWaRjIkPT_c7mDI4sgIQ&oe=61E6C760&_nc_sid=9a90d6",
                "title": "Tech vids",
                "url": "https://www.instagram.com/stories/highlights/18215511613028520/"
            },
            {
                "count": "18",
                "cover": "https://scontent-hel3-1.cdninstagram.com/v/t51.2885-15/s150x150/83405508_843407446110927_7215006586458308335_n.jpg?_nc_ht=scontent-hel3-1.cdninstagram.com&_nc_cat=103&_nc_ohc=4z-yI5QiccMAX887p9v&edm=ALbqBD0BAAAA&ccb=7-4&oh=00_AT-BAfKdpPm1fsMK9uc0BTrVxDl970-IgYqUunnatiDwTw&oe=61EADC72&_nc_sid=9a90d6",
                "title": "Keebs",
                "url": "https://www.instagram.com/stories/highlights/18127001746062846/"
            },
            {
                "count": "5",
                "cover": "https://scontent-hel3-1.cdninstagram.com/v/t51.2885-15/s150x150/80800756_769365663573637_3186183643259402826_n.jpg?_nc_ht=scontent-hel3-1.cdninstagram.com&_nc_cat=101&_nc_ohc=HsT9_vPTdTsAX_sLtIC&edm=ALbqBD0BAAAA&ccb=7-4&oh=00_AT-a3kVHyQmr5Pxap63UtGy5dTvJ7vicG9kgAoX2YQ-2pQ&oe=61EB4C6A&_nc_sid=9a90d6",
                "title": "Fuji",
                "url": "https://www.instagram.com/stories/highlights/17874793321510725/"
            },
            {
                "count": "15",
                "cover": "https://scontent-hel3-1.cdninstagram.com/v/t51.12442-15/e35/c0.398.1024.1024a/s150x150/79743836_107597967304789_8664623283568158246_n.jpg?_nc_ht=scontent-hel3-1.cdninstagram.com&_nc_cat=101&_nc_ohc=nr8PeFVkONgAX8Yvjk1&edm=ALbqBD0BAAAA&ccb=7-4&oh=00_AT_p0hdK0UtkGpFb9woIwz0maiwzhm-8Qj1zjKrfwPoMrw&oe=61E67A7F&_nc_sid=9a90d6",
                "title": "Highlights",
                "url": "https://www.instagram.com/stories/highlights/18011855272265308/"
            },
            {
                "count": "10",
                "cover": "https://scontent-hel3-1.cdninstagram.com/v/t51.12442-15/e35/c62.686.1152.1152a/s150x150/82491275_632810204148199_3431243930067546945_n.jpg?_nc_ht=scontent-hel3-1.cdninstagram.com&_nc_cat=107&_nc_ohc=d5IrqoD_EOAAX_Ns45b&edm=ALbqBD0BAAAA&ccb=7-4&oh=00_AT-0gdNaTQbLJYjahj9-zxO60Xo76Yv7f6Evrn4xFeg-fw&oe=61E706CC&_nc_sid=9a90d6",
                "title": "Coffee",
                "url": "https://www.instagram.com/stories/highlights/17888504560558454/"
            },
            {
                "count": "7",
                "cover": "https://scontent-hel3-1.cdninstagram.com/v/t51.2885-15/s150x150/82918566_590256921823069_298274361843760041_n.jpg?_nc_ht=scontent-hel3-1.cdninstagram.com&_nc_cat=101&_nc_ohc=tijjVl4yT0IAX82vS7V&edm=ALbqBD0BAAAA&ccb=7-4&oh=00_AT_q5zfvHg2UTavr-kc_DhRBZNqrDuEutoHFs3yNT6-_Uw&oe=61EC1CC1&_nc_sid=9a90d6",
                "title": "PC",
                "url": "https://www.instagram.com/stories/highlights/17850188428878472/"
            },
            {
                "count": "4",
                "cover": "https://scontent-hel3-1.cdninstagram.com/v/t51.12442-15/e35/c181.572.872.872a/s150x150/80851148_564335284117837_409924242645186461_n.jpg?_nc_ht=scontent-hel3-1.cdninstagram.com&_nc_cat=101&_nc_ohc=tW2mffhFMFgAX-Xr86W&edm=ALbqBD0BAAAA&ccb=7-4&oh=00_AT-GQAz2ki_9TVDwQ5LUysg9xpB9sRmGVK1utUbtcOxNAQ&oe=61E6746E&_nc_sid=9a90d6",
                "title": "Music",
                "url": "https://www.instagram.com/stories/highlights/17847201298879746/"
            },
            {
                "count": "14",
                "cover": "https://scontent-hel3-1.cdninstagram.com/v/t51.12442-15/e35/c0.398.1024.1024a/s150x150/75483278_2876215469057761_3338722808667694359_n.jpg?_nc_ht=scontent-hel3-1.cdninstagram.com&_nc_cat=101&_nc_ohc=AJ7_zffpuc0AX8DpNh1&edm=ALbqBD0BAAAA&ccb=7-4&oh=00_AT_DxbsymYJI9WZn8ChUJJtj3sqpbt2lVv7uSqYbBskxAg&oe=61E6FDB7&_nc_sid=9a90d6",
                "title": "Munich",
                "url": "https://www.instagram.com/stories/highlights/18048475666202625/"
            },
            {
                "count": "5",
                "cover": "https://scontent-hel3-1.cdninstagram.com/v/t51.12442-15/e35/c0.464.1335.1335a/s150x150/75580644_139236407366095_1396006015737176727_n.jpg?_nc_ht=scontent-hel3-1.cdninstagram.com&_nc_cat=107&_nc_ohc=nmAqhVTxBFcAX_d_eSB&edm=ALbqBD0BAAAA&ccb=7-4&oh=00_AT9JtFJbh1muWej0ZszoZ2fVQipK6-QihpCn1UW9aU0qXw&oe=61E67785&_nc_sid=9a90d6",
                "title": "Design",
                "url": "https://www.instagram.com/stories/highlights/17846790667819793/"
            },
            {
                "count": "9",
                "cover": "https://scontent-hel3-1.cdninstagram.com/v/t51.12442-15/e35/c46.395.968.968a/s150x150/35264005_181519912536748_7521238014543003648_n.jpg?_nc_ht=scontent-hel3-1.cdninstagram.com&_nc_cat=104&_nc_ohc=E8w2sXlG6ssAX9f0Swg&edm=ALbqBD0BAAAA&ccb=7-4&oh=00_AT9wPE-wbIvn0E3WBu6D7kHRweJH7qd0b3L_iEpszqurZQ&oe=61E6A671&_nc_sid=9a90d6",
                "title": "Amsterdam Trip",
                "url": "https://www.instagram.com/stories/highlights/17952619936047844/"
            }
        ],
        "id": "45376122",
        "lastpost": [
            {
                "caption": "The Maonocaster Lite is a complete podcasting set with mixer, microphone and sound effects card! Watch my latest video on youtube.com/andi\n\nThanks to @maonoglobal for sending over this piece of gear!\n\n#Maonocaster #maono #streamer #twitch #twitchstreamer #gamingsetup #streamsetup #microphone #gear #contentcreator #youtuber #gamingsetup #streamingsetup #twitchsetup #setup #battlestation #review #setupinspiration #gamingpc #pcgaming #setupgaming #setupgoals #deskinspiration",                "comment": "3",
                "created": "3 weeks ago",
                "like": "37",
                "page": "https://instagram.com/p/CX10T9Jtg7X/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/fr/e15/s1080x1080/269840027_441621354252343_5391433322229153982_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=107&_nc_ohc=Vgzu0zLJBw0AX9NED0E&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT_2k-WXgjTepB-rME68eenHL28sotGxTOqc3qFUXiZ6BQ&oe=61EB3E20&_nc_sid=7bff83"
            },
            {
                "caption": "The Maonocaster Lite is a full podcasting set that includes a mixer, microphone and sound effects card! Watch my latest video on youtube.com/andi where I check it out\n\nThanks to #maono for sending over this piece of gear!\n\n#Maonocaster #maono #streamer #twitch #twitchstreamer #gamingsetup #streamsetup #microphone #gear #contentcreator #youtuber #gamingsetup #streamingsetup #twitchsetup #setup #battlestation #review #setupinspiration #gamingpc #pcgaming #setupgaming #setupgoals #deskinspiration",
                "comment": "0",
                "created": "3 weeks ago",
                "like": "83",
                "page": "https://instagram.com/p/CX1zlJ5t7q8/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/fr/e15/s1080x1080/269777589_627931961866166_8992547253103200273_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=102&_nc_ohc=Xf73VBcDkDMAX_ohMkE&tn=E79ZiWTn3nldV1oe&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT-xUj54ubBiQE523LxIWfsb4sJnCTsL3AYNAjsKMaqfnw&oe=61EB6923&_nc_sid=7bff83"
            },
            {
                "caption": "Today I restored an iPhone 7 Plus to high performance by replacing the battery \u26a1\ufe0f\n\nWatch my video how I did on youtube.com/andi \n\nThanks @hughjeffreys for the inspiration and motivation to fix things! \ud83d\ude03 \n\nAnd thanks to @ifixit for the great teardowns! \n\n#iphonerepair #righttorepair #restoration #iphoneteardown #ifixit #teardown #repair #appleiphone",
                "comment": "19",
                "created": "a month ago",
                "like": "49",
                "page": "https://instagram.com/p/CWy-fWOtxyF/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/s1080x1080/261930838_380409373877035_8292617670858663256_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=107&_nc_ohc=1z-WSYQsmNQAX9N1afp&tn=E79ZiWTn3nldV1oe&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT_yJm0RKuhRvfSMlqYJ99b8qx68D_dSUYG0GdghYRPL4w&oe=61EBA958&_nc_sid=7bff83"
            },
            {
                "caption": "Upgrade your streaming and gaming setup with this budget friendly feature packed microphone from FiFine \ud83c\udfae\ud83c\udf99\n\nWatch my review on YouTube! \ud83d\udcfa youtube.com/andi \n\n#gamingsetup #streamingsetup #twitchsetup #setup #battlestation #microphone #fifine #youtuber #review #setupinspiration #gamingpc #pcgaming #twitchstreamer #setupgaming #setupgoals #deskinspiration #streamersetup #fifinemicrophone #fifinek690",
                "comment": "2",
                "created": "a month ago",
                "like": "66",
                "page": "https://instagram.com/p/CWsTLpwgjkQ/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/260714342_221693546766971_4097844274177742793_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=111&_nc_ohc=8MZnZeums6AAX-7E3v6&tn=E79ZiWTn3nldV1oe&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT9-1EAFz4vevtEt48r0cU_LAJ03vsduDtK4wremXpv8AA&oe=61EA6FC2&_nc_sid=7bff83"
            },
            {
                "caption": "Drop + MiTo GMK Laser Keycap Set \u26a1\ufe0fWatch the review on my YouTube channel! \n\n#drop #gmk #gmkkeycaps #gmklaser #cyberpunk #nk65 #customkeyboards #customkeycaps #customkeyboardbuild #coiledcable #customcables #mechanicalkeyboard #mechkeys #mechkeyboards #novelkeys #geekhack #gloriouspcgamingrace",
                "comment": "4",
                "created": "a month ago",
                "like": "1734",
                "page": "https://instagram.com/p/CWnVD33AIYw/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/260114844_723227355300409_8100005565102083459_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=101&_nc_ohc=fgwlpsRTKWkAX93sk07&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT84vPnCMO9qaFi1W0ueVfqG9I0ZrSuJPYFcfLeNVDV7Ig&oe=61EA89CD&_nc_sid=7bff83"
            },
            {
                "caption": "Unboxing some really high quality custom made mechanical keyboard cables made by @kriscables. Enjoy! \n\n#mechanicalkeyboard #customcables #mechkb #geekhack #artisan #customcable #pcmr",
                "comment": "6",
                "created": "4 months ago",
                "like": "34",
                "page": "https://instagram.com/p/CT9aEeWgXjp/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/p1080x1080/242180116_178717724397431_2673360790602922727_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=111&_nc_ohc=x4zXFi5doz4AX_r1V3H&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT-grfAkicqQRVGnFL3i3WDHw8AGhBtfoN4F0o5WsXbNSQ&oe=61E6C8A7&_nc_sid=7bff83"
            },
            {
                "caption": "Another shot featuring my all time favourite @hhkb_emea HHKB and @novel.keys NK65 together with custom cables by @kriscables. \n.\n.\n.\n.\n.\n#hhkb #hhkbtypes #hhkbhybrid #mechanicalkeyboard #customkeyboardbuild #customkeyboard #customkeyboards #customcables #geekhack #novelkeys #nk65",
                "comment": "0",
                "created": "4 months ago",
                "like": "83",
                "page": "https://instagram.com/p/CT8RYXZI2oG/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/s1080x1080/242077932_570909320990594_1202409664855870820_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=102&_nc_ohc=Ld-Sgmb3qIcAX9-qcd1&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT8hoLRifaNejMFHHuC9KPDiTnwyL9IYGCDZvULr53dVyg&oe=61EA85BF&_nc_sid=7bff83"
            },
            {
                "caption": "Coiled cables have to be my favourite keeb accessories. Made by @kriscables\n.\n.\n.\n.\n.\n#mechanicalkeyboard #customcables #hhkb #nk65 #novelkeys #kriscables #mechkb #geekhack #customkeyboardbuild",
                "comment": "2",
                "created": "4 months ago",
                "like": "30",
                "page": "https://instagram.com/p/CT8Q8voIKsu/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/s1080x1080/242236730_715677393167253_729940878586737615_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=109&_nc_ohc=q578jE2WmScAX-qICaw&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT_Ay4Pot7bS9R05L0JpXPm5Bun2CGWJFaIVTSfuf4A6Vg&oe=61EC08AE&_nc_sid=7bff83"
            },
            {
                "caption": "New profile picture! Pretty happy how this one turned out \u2728",
                "comment": "8",
                "created": "4 months ago",
                "like": "80",
                "page": "https://instagram.com/p/CT8Pu4ZNPzJ/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/242137991_227094956101542_5189923854992308868_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=106&_nc_ohc=va8b8WfCcB8AX_v_inx&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT_Clb9DnA3FI97QUbLv3jgLC6hvcfzKnEAyZljiD9PIJQ&oe=61EB6460&_nc_sid=7bff83"
            },
            {
                "caption": "New video! Lubing my NK65. Swipe for before and after typing sounds comparison \ud83d\ude04\n\nFirst time lubing mechanical keyboard switches for me, and after doing a lot of research I\u2019ve finally done it! \n\nWatch my latest video how it all went or read my blog post on blog.andi.yt \n\nHappy Friday! :D\n\n#mechanicalkeyboard #ramaworks #switchpuller #seq2 #customkeyboardbuild #customkeyboard #customkeyboards #gloriouspcgamingrace #gloriouspanda #keyboardswitches #typingsounds #nk65 #kbdfans #cannonkeys #omnitype #deskpad #krytox205g0 #kriscables",
                "comment": "62",
                "created": "7 months ago",
                "like": "88",
                "page": "https://instagram.com/p/CQiphIYBrUc/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/s1080x1080/208339512_2843970515867785_8910013834601068198_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=101&_nc_ohc=zbNNk-3FMg0AX-R86Hy&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT_FIsKBxvbuV1LrCpiYrmpRVTAh9N3Zl9fKlWojyqPRTg&oe=61EBFD48&_nc_sid=7bff83"
            },
            {
                "caption": "Watch my latest video where I review the @tplinkus Deco X60 Mesh WIFI 6 system 2 months later - link in my bio\n\n#review #tplink #wifi6 #meshwifi #homenetwork #technology #techreview #youtuber #youtube #mesh #wifi",
                "comment": "5",
                "created": "7 months ago",
                "like": "58",
                "page": "https://instagram.com/p/CQQp2yZBOCp/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/s1080x1080/201426104_1006561003418137_4361941053730791697_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=101&_nc_ohc=tSB8N-D3kQAAX9AAfNd&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT9VPX2NrqAlJRSkBaTQkkEaDoMLe4zc3fuObJHVSc6bXw&oe=61EBD55B&_nc_sid=7bff83"
            },
            {
                "caption": "Happy Friday! Watch my new video where I'm building my ultimate purple mechanical keyboard with the NK65 aluminium \u2728 Link in bio!\n\n@novel.keys NK65 v2 aluminium midnight purple\n@cannon.keys NicePBT sugarplum keycaps\n@gloriouspcgamingrace Panda switches \n@kriscables Coiled cable\n@omnitype Deskmat from @mykeyboard.eu\n\n#mechkeyboard #mechanicalkeyboard #nk65 #nk65v2 #nicepbt #sugarplum #customkeyboard #customcable #pandaswitches #panda #gloriouspcgamingrace #novelkeys #geekhack #keyboard #pcmr #omnitype #tactile #mechkb",
                "comment": "7",
                "created": "8 months ago",
                "like": "81",
                "page": "https://instagram.com/p/CPaeiHmh06z/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/192206806_315758376928571_7916550654721661808_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=111&_nc_ohc=3tEpJWfHnmEAX_CXR4n&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT9q0QEedFZPENJBMFqmMcKvOWhAvu7KS829cd1amWv0Jg&oe=61EB7A40&_nc_sid=7bff83"
            }
        ],
        "picture": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-19/s320x320/240695884_149259844026432_8181951245983860462_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=100&_nc_ohc=DUWd50PTQeEAX8vO3fR&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT8wl6xw9zqptjlw37ab7G1UmP5huDfvzdc0qqYKJ38Svw&oe=61EB65BB&            },
            {
                "caption": "Watch my latest video where I review the @tplinkus Deco X60 Mesh WIFI 6 system 2 months later - link in my bio\n\n#review #tplink #wifi6 #meshwifi #homenetwork #technology #techreview #youtuber #youtube #mesh #wifi",
                "comment": "5",
                "created": "7 months ago",
                "like": "58",
                "page": "https://instagram.com/p/CQQp2yZBOCp/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/s1080x1080/201426104_1006561003418137_4361941053730791697_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=101&_nc_ohc=tSB8N-D3kQAAX9AAfNd&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT9VPX2NrqAlJRSkBaTQkkEaDoMLe4zc3fuObJHVSc6bXw&oe=61EBD55B&_nc_sid=7bff83"
            },
            {
                "caption": "Happy Friday! Watch my new video where I'm building my ultimate purple mechanical keyboard with the NK65 aluminium \u2728 Link in bio!\n\n@novel.keys NK65 v2 aluminium midnight purple\n@cannon.keys NicePBT sugarplum keycaps\n@gloriouspcgamingrace Panda switches \n@kriscables Coiled cable\n@omnitype Deskmat from @mykeyboard.eu\n\n#mechkeyboard #mechanicalkeyboard #nk65 #nk65v2 #nicepbt #sugarplum #customkeyboard #customcable #pandaswitches #panda #gloriouspcgamingrace #novelkeys #geekhack #keyboard #pcmr #omnitype #tactile #mechkb",
                "comment": "7",
                "created": "8 months ago",
                "like": "81",
                "page": "https://instagram.com/p/CPaeiHmh06z/",
                "url": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-15/e35/192206806_315758376928571_7916550654721661808_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=111&_nc_ohc=3tEpJWfHnmEAX_CXR4n&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT9q0QEedFZPENJBMFqmMcKvOWhAvu7KS829cd1amWv0Jg&oe=61EB7A40&_nc_sid=7bff83"
            }
        ],
        "picture": "https://scontent-sea1-1.cdninstagram.com/v/t51.2885-19/s320x320/240695884_149259844026432_8181951245983860462_n.jpg?_nc_ht=scontent-sea1-1.cdninstagram.com&_nc_cat=100&_nc_ohc=DUWd50PTQeEAX8vO3fR&edm=ABfd0MgBAAAA&ccb=7-4&oh=00_AT8wl6xw9zqptjlw37ab7G1UmP5huDfvzdc0qqYKJ38Svw&oe=61EB65BB&_nc_sid=7bff83",
        "post": "164",
        "private": false,
        "profile": "https://www.instagram.com/andi/",
        "username": "andi",
        "verified": false,
        "website": "https://andi.yt/"
    },
    "status": 200
}